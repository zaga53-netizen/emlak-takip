package com.example.emlaktakip;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout list; TextView summary; EditText name,rent,month; Spinner propertyFilter; String currentMonth; long filterPropertyId = -1; ArrayList<Long> filterIds = new ArrayList<>(); boolean updatingFilter=false;
    long tenantPropertyId = -1; EditText tenantName, tenantPhone, tenantTc, tenantAddress, tenantDeposit, tenantStartDate, tenantContractDate, tenantNotes; ImageView tenantImage; String tenantImageUri = "";

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main); db=new DB(this);
        list=findViewById(R.id.list); summary=findViewById(R.id.summary); name=findViewById(R.id.name); rent=findViewById(R.id.rent); month=findViewById(R.id.month); propertyFilter=findViewById(R.id.propertyFilter);
        currentMonth=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date()); month.setText(currentMonth);
        findViewById(R.id.addProperty).setOnClickListener(v->add());
        findViewById(R.id.refresh).setOnClickListener(v->{currentMonth=validMonth();refresh();});
        findViewById(R.id.yearReport).setOnClickListener(v->yearReport()); propertyFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id){ if(updatingFilter) return; if(pos>=0 && pos<filterIds.size()) filterPropertyId=filterIds.get(pos); refresh(); } public void onNothingSelected(android.widget.AdapterView<?> p){} }); refresh();
    }

    String validMonth(){String s=month.getText().toString().trim(); if(!s.matches("\\d{4}-\\d{2}")){toast("Ayı YYYY-AA şeklinde yaz. Örn. 2026-09");return currentMonth;} int m=Integer.parseInt(s.substring(5)); if(m<1||m>12){toast("Ay 01 ile 12 arasında olmalı.");return currentMonth;} return s;}
    void add(){String n=name.getText().toString().trim(); double r=num(rent.getText().toString()); if(n.isEmpty()){toast("Gayrimenkul adını yaz.");return;} db.add(n,r); name.setText("");rent.setText("");refresh();}
    double num(String s){try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;}}

    void updatePropertyFilter(){
        Cursor c=db.properties(); ArrayList<String> labels=new ArrayList<>(); filterIds.clear();
        labels.add("Tüm gayrimenkuller"); filterIds.add(-1L);
        while(c.moveToNext()){ labels.add(c.getString(1)); filterIds.add(c.getLong(0)); } c.close();
        boolean changed = propertyFilter.getAdapter()==null || propertyFilter.getAdapter().getCount()!=labels.size();
        if(changed){ updatingFilter=true; ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels); a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); propertyFilter.setAdapter(a); updatingFilter=false; }
        int wanted=0; for(int i=0;i<filterIds.size();i++) if(filterIds.get(i)==filterPropertyId){wanted=i;break;}
        if(propertyFilter.getSelectedItemPosition()!=wanted){ updatingFilter=true; propertyFilter.setSelection(wanted,false); updatingFilter=false; }
    }

    void refresh(){
        currentMonth=validMonth(); list.removeAllViews(); updatePropertyFilter(); double income=0,expense=0; Cursor c=db.properties();
        while(c.moveToNext()){
            long id=c.getLong(0); String n=c.getString(1); double r=c.getDouble(2);
            if(filterPropertyId!=-1 && id!=filterPropertyId) continue; double paid=db.paid(id,currentMonth); double e=db.expense(id,currentMonth); income+=paid; expense+=e;
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(0,12,0,12);
            TextView t=new TextView(this); t.setText(n+"\nAylık kira: "+money(r)+"\n"+(paid>=r&&r>0?"✅ Kira ödendi":"❌ Kira bekliyor")+"\nBu ay gider: "+money(e)); t.setTextSize(17); row.addView(t);
            LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.VERTICAL);
            LinearLayout line1=new LinearLayout(this); Button pay=new Button(this); pay.setText(paid>=r&&r>0?"Ödemeyi kaldır":"Kira ödendi"); pay.setOnClickListener(v->{if(paid>=r&&r>0)db.removePayment(id,currentMonth);else db.payment(id,currentMonth,r);refresh();}); Button ge=new Button(this); ge.setText("Gider ekle"); ge.setOnClickListener(v->expense(id)); line1.addView(pay,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1)); line1.addView(ge,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1)); buttons.addView(line1);
            LinearLayout line2=new LinearLayout(this); Button tenant=new Button(this); tenant.setText("Kiracı bilgileri"); tenant.setOnClickListener(v->tenantDialog(id,n)); Button del=new Button(this); del.setText("Sil"); del.setOnClickListener(v->{db.del(id);refresh();}); line2.addView(tenant,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1)); line2.addView(del,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1)); buttons.addView(line2);
            row.addView(buttons); list.addView(row);
        }
        c.close(); summary.setText("Seçili ay: "+currentMonth+"\nÖdenen kira: "+money(income)+" | Gider: "+money(expense)+" | Net: "+money(income-expense));
    }

    void tenantDialog(long propertyId,String propertyName){
        tenantPropertyId=propertyId; Cursor c=db.tenant(propertyId); String oldName="",oldPhone="",oldTc="",oldAddress="",oldDeposit="",oldStartDate="",oldContractDate="",oldNotes="",oldUri="";
        if(c.moveToFirst()){oldName=c.getString(0);oldPhone=c.getString(1);oldTc=c.getString(2);oldAddress=c.getString(3);oldDeposit=c.getString(4);oldStartDate=c.getString(5);oldContractDate=c.getString(6);oldNotes=c.getString(7);oldUri=c.getString(8);} c.close(); tenantImageUri=oldUri==null?"":oldUri;
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,0,30,0);
        tenantName=new EditText(this); tenantName.setHint("Kiracı adı soyadı"); tenantName.setText(oldName); box.addView(tenantName);
        tenantPhone=new EditText(this); tenantPhone.setHint("Telefon numarası"); tenantPhone.setInputType(InputType.TYPE_CLASS_PHONE); tenantPhone.setText(oldPhone); box.addView(tenantPhone);
        tenantTc=new EditText(this); tenantTc.setHint("T.C. kimlik no"); tenantTc.setInputType(InputType.TYPE_CLASS_NUMBER); tenantTc.setText(oldTc); box.addView(tenantTc);
        tenantAddress=new EditText(this); tenantAddress.setHint("Kiracı adresi"); tenantAddress.setGravity(Gravity.TOP); tenantAddress.setMinLines(2); tenantAddress.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); tenantAddress.setText(oldAddress); box.addView(tenantAddress);
        tenantDeposit=new EditText(this); tenantDeposit.setHint("Depozito (TL)"); tenantDeposit.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); tenantDeposit.setText(oldDeposit); box.addView(tenantDeposit);
        tenantStartDate=new EditText(this); tenantStartDate.setHint("Kira başlangıç tarihi (GG.AA.YYYY)"); tenantStartDate.setInputType(InputType.TYPE_CLASS_DATETIME); tenantStartDate.setText(oldStartDate); box.addView(tenantStartDate);
        tenantContractDate=new EditText(this); tenantContractDate.setHint("Sözleşme tarihi (GG.AA.YYYY)"); tenantContractDate.setInputType(InputType.TYPE_CLASS_DATETIME); tenantContractDate.setText(oldContractDate); box.addView(tenantContractDate);
        tenantNotes=new EditText(this); tenantNotes.setHint("Notlar"); tenantNotes.setGravity(Gravity.TOP); tenantNotes.setMinLines(4); tenantNotes.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); tenantNotes.setText(oldNotes); box.addView(tenantNotes);
        tenantImage=new ImageView(this); tenantImage.setAdjustViewBounds(true); tenantImage.setMinimumHeight(220); tenantImage.setBackgroundColor(Color.LTGRAY); box.addView(tenantImage);
        if(!tenantImageUri.isEmpty()) loadImage(tenantImage,tenantImageUri);
        Button imageBtn=new Button(this); imageBtn.setText("Resim ekle / değiştir"); imageBtn.setOnClickListener(v->pickImage()); box.addView(imageBtn);
        new AlertDialog.Builder(this).setTitle("Kiracı bilgileri\n"+propertyName).setView(box).setPositiveButton("Kaydet",(d,w)->{db.saveTenant(propertyId,tenantName.getText().toString().trim(),tenantPhone.getText().toString().trim(),tenantTc.getText().toString().trim(),tenantAddress.getText().toString().trim(),tenantDeposit.getText().toString().trim(),tenantStartDate.getText().toString().trim(),tenantContractDate.getText().toString().trim(),tenantNotes.getText().toString().trim(),tenantImageUri);refresh();}).setNegativeButton("İptal",null).show();
    }

    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,1001);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data); if(requestCode==1001&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData(); tenantImageUri=u.toString(); try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} if(tenantImage!=null)loadImage(tenantImage,tenantImageUri);}}
    void loadImage(ImageView v,String uri){try{v.setImageURI(Uri.parse(uri));}catch(Exception ignored){}}

    void expense(long id){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(30,0,30,0);EditText cat=new EditText(this);cat.setHint("Gider türü (aidat, tamirat...) ");EditText x=new EditText(this);x.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);x.setHint("Tutar (TL)");box.addView(cat);box.addView(x);new AlertDialog.Builder(this).setTitle("Gider ekle - "+currentMonth).setView(box).setPositiveButton("Ekle",(d,w)->{double v=num(x.getText().toString());if(v>0)db.exp(id,currentMonth,cat.getText().toString().trim(),v);refresh();}).setNegativeButton("İptal",null).show();}
    void yearReport(){final EditText y=new EditText(this);y.setInputType(InputType.TYPE_CLASS_NUMBER);y.setText(currentMonth.substring(0,4));new AlertDialog.Builder(this).setTitle("Yıllık rapor").setView(y).setPositiveButton("Göster",(d,w)->{String year=y.getText().toString().trim();if(!year.matches("\\d{4}")){toast("Yılı 4 haneli yaz.");return;}double inc=db.yearIncome(year),exp=db.yearExpense(year);new AlertDialog.Builder(this).setTitle(year+" Raporu").setMessage("Toplam kira tahsilatı: "+money(inc)+"\nToplam gider: "+money(exp)+"\n\nNet gelir: "+money(inc-exp)).setPositiveButton("Tamam",null).show();}).setNegativeButton("İptal",null).show();}
    String money(double v){return String.format(Locale.US,"%,.0f TL",v).replace(',', '.');} void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"emlak.db",null,4);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE p(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,rent REAL,expense REAL DEFAULT 0)");d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER,month TEXT,amount REAL)");d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER,month TEXT,category TEXT,amount REAL)");d.execSQL("CREATE TABLE tenants(property_id INTEGER PRIMARY KEY,name TEXT,phone TEXT,tc_no TEXT,address TEXT,deposit TEXT,start_date TEXT,contract_date TEXT,notes TEXT,image_uri TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){if(a<2){d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER,month TEXT,amount REAL)");d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER,month TEXT,category TEXT,amount REAL)");}if(a<3){d.execSQL("CREATE TABLE tenants(property_id INTEGER PRIMARY KEY,name TEXT,phone TEXT,notes TEXT,image_uri TEXT)");}if(a<4){d.execSQL("ALTER TABLE tenants ADD COLUMN tc_no TEXT");d.execSQL("ALTER TABLE tenants ADD COLUMN address TEXT");d.execSQL("ALTER TABLE tenants ADD COLUMN deposit TEXT");d.execSQL("ALTER TABLE tenants ADD COLUMN start_date TEXT");d.execSQL("ALTER TABLE tenants ADD COLUMN contract_date TEXT");}}
        void add(String n,double r){ContentValues v=new ContentValues();v.put("name",n);v.put("rent",r);v.put("expense",0);getWritableDatabase().insert("p",null,v);} void del(long id){SQLiteDatabase d=getWritableDatabase();d.delete("payments","property_id=?",new String[]{""+id});d.delete("expenses","property_id=?",new String[]{""+id});d.delete("tenants","property_id=?",new String[]{""+id});d.delete("p","id=?",new String[]{""+id});}
        Cursor properties(){return getReadableDatabase().rawQuery("SELECT id,name,rent FROM p ORDER BY id DESC",null);} double paid(long id,String m){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE property_id=? AND month=?",new String[]{""+id,m});double v=0;if(c.moveToFirst())v=c.getDouble(0);c.close();return v;} double expense(long id,String m){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE property_id=? AND month=?",new String[]{""+id,m});double v=0;if(c.moveToFirst())v=c.getDouble(0);c.close();return v;}
        void payment(long id,String m,double a){ContentValues v=new ContentValues();v.put("property_id",id);v.put("month",m);v.put("amount",a);getWritableDatabase().insert("payments",null,v);} void removePayment(long id,String m){getWritableDatabase().delete("payments","property_id=? AND month=?",new String[]{""+id,m});} void exp(long id,String m,String cat,double a){ContentValues v=new ContentValues();v.put("property_id",id);v.put("month",m);v.put("category",cat.isEmpty()?"Genel":cat);v.put("amount",a);getWritableDatabase().insert("expenses",null,v);}
        Cursor tenant(long id){return getReadableDatabase().rawQuery("SELECT name,phone,tc_no,address,deposit,start_date,contract_date,notes,image_uri FROM tenants WHERE property_id=?",new String[]{""+id});}
        void saveTenant(long id,String name,String phone,String tc,String address,String deposit,String startDate,String contractDate,String notes,String uri){ContentValues v=new ContentValues();v.put("property_id",id);v.put("name",name);v.put("phone",phone);v.put("tc_no",tc);v.put("address",address);v.put("deposit",deposit);v.put("start_date",startDate);v.put("contract_date",contractDate);v.put("notes",notes);v.put("image_uri",uri);getWritableDatabase().insertWithOnConflict("tenants",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
        double yearIncome(String y){return sum("payments",y);} double yearExpense(String y){return sum("expenses",y);} double sum(String table,String y){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM "+table+" WHERE month LIKE ?",new String[]{y+"-%"});double v=0;if(c.moveToFirst())v=c.getDouble(0);c.close();return v;}
    }
}
